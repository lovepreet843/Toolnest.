import type { CapacitorConfig } from '@capacitor/cli'
const config: CapacitorConfig = { appId: 'app.toolnest.android', appName: 'TOOLNEST', webDir: 'dist', backgroundColor: '#07081a',
  plugins: { SplashScreen: { launchShowDuration: 1200, backgroundColor: '#07081a', showSpinner: false } } }
export default config
