import { admin, cors, json, userFrom } from '../_shared/util.ts'
Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: cors })
  const user = await userFrom(req); if (!user) return json({ error: 'Please log in.' }, 401)
  const { confirm } = await req.json().catch(() => ({})); if (confirm !== 'DELETE') return json({ error: 'Type DELETE to confirm.' }, 400)
  const { error } = await admin().auth.admin.deleteUser(user.id); if (error) { console.error(error); return json({ error: 'Could not delete account.' }, 500) }
  return json({ ok: true })
})
