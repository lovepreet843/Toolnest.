import { admin } from '../_shared/util.ts'
const hex = (b: ArrayBuffer) => [...new Uint8Array(b)].map((x) => x.toString(16).padStart(2, '0')).join('')
Deno.serve(async (req) => {
  const secret = Deno.env.get('RAZORPAY_WEBHOOK_SECRET'); if (!secret) return new Response('not configured', { status: 503 })
  const raw = await req.text(), sig = req.headers.get('x-razorpay-signature') ?? ''
  const k = await crypto.subtle.importKey('raw', new TextEncoder().encode(secret), { name: 'HMAC', hash: 'SHA-256' }, false, ['sign'])
  const expected = hex(await crypto.subtle.sign('HMAC', k, new TextEncoder().encode(raw)))
  if (expected.length !== sig.length || expected !== sig) return new Response('bad signature', { status: 400 })
  const eventId = req.headers.get('x-razorpay-event-id'); if (!eventId) return new Response('no event id', { status: 400 })
  const db = admin()
  const { error: dup } = await db.from('webhook_events').insert({ event_id: eventId }); if (dup) return new Response('duplicate', { status: 200 }) // idempotent
  const ev = JSON.parse(raw), pay = ev.payload?.payment?.entity
  if (ev.event === 'payment.captured' && pay) {
    const { data: p } = await db.from('payments').select('*').eq('provider_order_id', pay.order_id).maybeSingle()
    if (p && p.status !== 'paid' && pay.amount === p.amount_paise && pay.currency === 'INR') {
      const { data: plan } = await db.from('plans').select('ai_credits').eq('id', p.plan_id).single()
      await db.from('payments').update({ status: 'paid', provider_payment_id: pay.id }).eq('id', p.id)
      await db.from('profiles').update({ plan_id: p.plan_id, credits: plan!.ai_credits * (p.billing_cycle === 'yearly' ? 12 : 1), plan_expires_at: new Date(Date.now() + (p.billing_cycle === 'yearly' ? 365 : 30) * 864e5).toISOString() }).eq('id', p.user_id)
      await db.from('audit_logs').insert({ action: 'plan_activated', detail: { user: p.user_id, plan: p.plan_id, payment: pay.id } })
    }
  } else if (ev.event === 'payment.failed' && pay) await db.from('payments').update({ status: 'failed' }).eq('provider_order_id', pay.order_id).eq('status', 'created')
  else if (ev.event === 'refund.processed') { const pid = ev.payload?.refund?.entity?.payment_id; if (pid) await db.from('payments').update({ status: 'refunded' }).eq('provider_payment_id', pid) }
  return new Response('ok')
})
