import { cors, json } from '../_shared/util.ts'
import { guard, openai, refund } from '../_shared/ai.ts'
Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: cors })
  try {
    const { conversation_id, message, stream, regenerate } = await req.json()
    if (typeof message !== 'string' || !message.trim() || message.length > 12000) return json({ error: 'Message must be 1–12000 characters.' }, 400)
    const g = await guard(req); if (g instanceof Response) return g
    const { db, user } = g; let cid = (conversation_id as string | null) ?? null
    if (cid) {
      const { data: c } = await db.from('conversations').select('id').eq('id', cid).eq('user_id', user.id).maybeSingle()
      if (!c) { await refund(g, 'chat'); return json({ error: 'Conversation not found.' }, 404) }
      if (regenerate) { const { data: last } = await db.from('messages').select('id').eq('conversation_id', cid).order('created_at', { ascending: false }).limit(2); if (last?.length) await db.from('messages').delete().in('id', last.map((m) => m.id)) }
    } else { const { data: c } = await db.from('conversations').insert({ user_id: user.id, title: message.slice(0, 60) }).select('id').single(); cid = c!.id }
    const { data: hist } = await db.from('messages').select('role,content').eq('conversation_id', cid).order('created_at').limit(20)
    const body = { instructions: 'You are TOOLNEST AI, a concise, helpful assistant.', input: [...(hist ?? []), { role: 'user', content: message }] }
    const save = async (reply: string, tokens: number) => {
      await db.from('messages').insert([{ conversation_id: cid, user_id: user.id, role: 'user', content: message }, { conversation_id: cid, user_id: user.id, role: 'assistant', content: reply }])
      await db.from('ai_usage').insert({ user_id: user.id, model: g.model, credits: g.cost, tool: 'chat', tokens })
    }
    if (!stream) {
      const r = await openai(g, body); if (!r.ok) { console.error('openai', r.status, await r.text()); await refund(g, 'chat'); return json({ error: 'AI provider error. You were not charged.' }, 502) }
      const d = await r.json(); const reply: string = d.output_text ?? (d.output ?? []).flatMap((o: any) => o.content ?? []).map((c: any) => c.text ?? '').join('')
      await save(reply, d.usage?.total_tokens ?? 0); return json({ reply, conversation_id: cid, credits_left: g.left })
    }
    const r = await openai(g, { ...body, stream: true })
    if (!r.ok || !r.body) { console.error('openai', r.status, await r.text()); await refund(g, 'chat'); return json({ error: 'AI provider error. You were not charged.' }, 502) }
    const enc = new TextEncoder(), dec = new TextDecoder(), reader = r.body.getReader(); let full = '', tokens = 0, buf = ''
    const send = (c: ReadableStreamDefaultController, o: unknown) => c.enqueue(enc.encode(`data: ${JSON.stringify(o)}\n\n`))
    const out = new ReadableStream({
      async start(c) {
        send(c, { meta: { conversation_id: cid, credits_left: g.left } })
        try {
          for (;;) {
            const { done, value } = await reader.read(); if (done) break
            buf += dec.decode(value, { stream: true }); const lines = buf.split('\n'); buf = lines.pop()!
            for (const l of lines) { if (!l.startsWith('data: ')) continue; try { const e = JSON.parse(l.slice(6))
              if (e.type === 'response.output_text.delta') { full += e.delta; send(c, { delta: e.delta }) } else if (e.type === 'response.completed') tokens = e.response?.usage?.total_tokens ?? 0 } catch { /* non-JSON line */ } }
          }
          if (!full) throw new Error('empty')
          await save(full, tokens); send(c, { done: true })
        } catch (e) { console.error(e); if (!full) { await refund(g, 'chat'); send(c, { error: 'AI stream failed. You were not charged.' }) } else { await save(full, tokens); send(c, { error: 'Stream interrupted.' }) } }
        c.close()
      },
    })
    return new Response(out, { headers: { ...cors, 'Content-Type': 'text/event-stream', 'Cache-Control': 'no-cache' } })
  } catch (e) { console.error(e); return json({ error: 'Something went wrong.' }, 500) }
})
