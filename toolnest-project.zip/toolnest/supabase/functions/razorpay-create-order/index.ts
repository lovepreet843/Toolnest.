import { admin, cors, json, userFrom } from '../_shared/util.ts'
Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: cors })
  try {
    const user = await userFrom(req); if (!user) return json({ error: 'Please log in.' }, 401)
    const id = Deno.env.get('RAZORPAY_KEY_ID'), secret = Deno.env.get('RAZORPAY_KEY_SECRET'); if (!id || !secret) return json({ error: 'Payments are not configured.' }, 503)
    const { plan_id, cycle } = await req.json(); const db = admin()
    const { data: plan } = await db.from('plans').select('id,price_inr,price_yearly_inr').eq('id', plan_id).eq('active', true).maybeSingle()
    if (!plan || plan.price_inr <= 0) return json({ error: 'Invalid plan.' }, 400)
    const yearly = cycle === 'yearly', amount = (yearly ? (plan.price_yearly_inr ?? plan.price_inr * 10) : plan.price_inr) * 100  // price comes from DB, never from the client
    const r = await fetch('https://api.razorpay.com/v1/orders', { method: 'POST', headers: { Authorization: 'Basic ' + btoa(`${id}:${secret}`), 'Content-Type': 'application/json' }, body: JSON.stringify({ amount, currency: 'INR', receipt: crypto.randomUUID().slice(0, 30) }) })
    if (!r.ok) { console.error('razorpay', await r.text()); return json({ error: 'Could not create order.' }, 502) }
    const o = await r.json()
    await db.from('payments').insert({ user_id: user.id, plan_id: plan.id, amount_paise: amount, provider_order_id: o.id, billing_cycle: yearly ? 'yearly' : 'monthly' })
    return json({ order_id: o.id, amount, currency: 'INR', key_id: id })
  } catch (e) { console.error(e); return json({ error: 'Something went wrong.' }, 500) }
})
