import { admin, cors, json } from '../_shared/util.ts'
import { guard, openai, refund } from '../_shared/ai.ts'
// Server-side prompt templates: the client only sends a tool id, never the prompt.
const T: Record<string, string> = {
  writer: 'You are a professional writer. Produce polished, original content that follows the request. Match the requested tone.',
  summarizer: 'Summarize the text faithfully: a 2-sentence overview, then key points as bullets. Do not add facts.',
  translator: 'Translate the text into the target language. Output only the translation.',
  email: 'Write a clear, well-structured email with a subject line. Match the requested tone.',
  code: 'You are a senior software engineer. Explain, write, debug or review code. Use fenced code blocks and be concise.',
  study: 'You are a patient tutor. Explain step by step, give a simple example, then 3 practice questions.',
  social: 'Create social media content: 3 caption options, relevant hashtags, and a posting tip. Match the requested tone.',
  resume: 'Create an ATS-friendly resume or cover letter from the details given. Never invent employers, degrees or dates; use [placeholders] for missing facts.',
}
Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: cors })
  try {
    const { tool, input, option } = await req.json()
    if (!T[tool]) return json({ error: 'Unknown tool.' }, 400)
    if (typeof input !== 'string' || !input.trim() || input.length > 12000) return json({ error: 'Input must be 1–12000 characters.' }, 400)
    const opt = typeof option === 'string' ? option.replace(/[^\p{L}\p{N} \-]/gu, '').slice(0, 40) : ''
    const { data: s } = await admin().from('settings').select('value').eq('key', 'premium_tools').maybeSingle()
    const g = await guard(req, (s?.value ?? 'code,resume').split(',').includes(tool)); if (g instanceof Response) return g
    const r = await openai(g, { instructions: T[tool] + (opt ? ` Option: ${opt}.` : ''), input })
    if (!r.ok) { console.error('openai', r.status, await r.text()); await refund(g, tool); return json({ error: 'AI provider error. You were not charged.' }, 502) }
    const d = await r.json(); const reply: string = d.output_text ?? (d.output ?? []).flatMap((o: any) => o.content ?? []).map((c: any) => c.text ?? '').join('')
    await g.db.from('ai_usage').insert({ user_id: g.user.id, model: g.model, credits: g.cost, tool, tokens: d.usage?.total_tokens ?? 0 })
    return json({ reply, credits_left: g.left })
  } catch (e) { console.error(e); return json({ error: 'Something went wrong.' }, 500) }
})
