import { admin, json, userFrom } from './util.ts'
// Auth, plan expiry, premium gate, rate limit, atomic credit spend. Returns a Response on failure.
export async function guard(req: Request, premium = false) {
  const user = await userFrom(req); if (!user) return json({ error: 'Please log in.' }, 401)
  const key = Deno.env.get('OPENAI_API_KEY'); if (!key) return json({ error: 'AI is not configured on the server.' }, 503)
  const db = admin(); await db.rpc('expire_user_plan', { p_user: user.id })
  const { data: s } = await db.from('settings').select('key,value'); const cfg = Object.fromEntries((s ?? []).map((r) => [r.key, r.value]))
  const model = cfg.ai_model ?? Deno.env.get('OPENAI_MODEL') ?? 'gpt-4o-mini', cost = Number(cfg.credit_cost_per_message ?? 1), rpm = Number(cfg.ai_requests_per_minute ?? 10)
  if (premium) { const { data: p } = await db.from('profiles').select('plan_id').eq('id', user.id).single(); if (p?.plan_id === 'free') return json({ error: 'This tool needs a Pro or Premium plan.' }, 403) }
  const { count } = await db.from('ai_usage').select('id', { count: 'exact', head: true }).eq('user_id', user.id).gte('created_at', new Date(Date.now() - 60_000).toISOString())
  if ((count ?? 0) >= rpm) return json({ error: 'Too many requests. Wait a minute.' }, 429)
  const { data: left, error } = await db.rpc('spend_credits', { p_user: user.id, p_cost: cost })
  if (error || left === null) return json({ error: 'Out of AI credits. Upgrade your plan.' }, 402)
  return { user, db, key, model, cost, left: left as number, cfg }
}
export type Guard = Exclude<Awaited<ReturnType<typeof guard>>, Response>
export const openai = (g: Guard, body: Record<string, unknown>) => fetch('https://api.openai.com/v1/responses', { method: 'POST', headers: { Authorization: `Bearer ${g.key}`, 'Content-Type': 'application/json' }, body: JSON.stringify({ model: g.model, max_output_tokens: 1500, ...body }) })
export const refund = async (g: Guard, tool?: string) => { await g.db.rpc('refund_credits', { p_user: g.user.id, p_cost: g.cost }); await g.db.from('ai_usage').insert({ user_id: g.user.id, model: g.model, credits: 0, ok: false, tool }) }
