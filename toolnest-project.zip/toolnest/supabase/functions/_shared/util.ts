import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.45.0'
export const cors = { 'Access-Control-Allow-Origin': Deno.env.get('ALLOWED_ORIGIN') ?? '*', 'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type', 'Content-Type': 'application/json' }
export const json = (b: unknown, s = 200) => new Response(JSON.stringify(b), { status: s, headers: cors })
export const admin = () => createClient(Deno.env.get('SUPABASE_URL')!, Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!)
export async function userFrom(req: Request) {
  const token = (req.headers.get('Authorization') ?? '').replace('Bearer ', ''); if (!token) return null
  const { data } = await admin().auth.getUser(token); return data.user
}
