-- Manual UPI payments. All writes go through SECURITY DEFINER functions; no direct table writes for clients.
update public.plans set name='Premium' where id='max';
update public.plans set active=false where id='mini';   -- Free / Pro / Premium shown; admin can re-enable Mini

create table public.manual_payments (
  id uuid primary key default gen_random_uuid(),
  order_code text unique not null,
  user_id uuid not null references public.profiles(id) on delete cascade,
  plan_id text not null references public.plans(id),
  amount_paise int not null check (amount_paise > 0),
  utr text,
  status text not null default 'awaiting_utr' check (status in ('awaiting_utr','pending_verification','approved','rejected')),
  submitted_at timestamptz, reviewed_by uuid references auth.users, reviewed_at timestamptz, reject_reason text, activated_at timestamptz,
  created_at timestamptz not null default now(),
  constraint utr_format check (utr is null or utr ~ '^[0-9]{12}$'));
create unique index manual_payments_utr_key on public.manual_payments(utr) where utr is not null;  -- duplicate UTR blocked, incl. rejected ones

create table public.notifications (id uuid primary key default gen_random_uuid(), user_id uuid not null references auth.users on delete cascade, title text not null, body text, read boolean not null default false, created_at timestamptz default now());

alter table public.manual_payments enable row level security; alter table public.notifications enable row level security;
create policy mp_select on public.manual_payments for select using (user_id=auth.uid() or public.is_admin());
create policy notif_select on public.notifications for select using (user_id=auth.uid());
create policy notif_update on public.notifications for update using (user_id=auth.uid()) with check (user_id=auth.uid());
revoke insert, update, delete on public.manual_payments from anon, authenticated;
revoke insert, update, delete on public.notifications from anon, authenticated;
grant update (read) on public.notifications to authenticated;

create or replace function public.create_upi_order(p_plan text) returns public.manual_payments language plpgsql security definer set search_path=public as $$
declare pl public.plans; o public.manual_payments;
begin
  if auth.uid() is null then raise exception 'Login required'; end if;
  select * into pl from plans where id=p_plan and active and price_inr>0;
  if not found then raise exception 'Invalid plan'; end if;
  select * into o from manual_payments where user_id=auth.uid() and plan_id=p_plan and status='awaiting_utr' limit 1;
  if found then return o; end if;
  if (select count(*) from manual_payments where user_id=auth.uid() and status in ('awaiting_utr','pending_verification')) >= 3 then raise exception 'Too many open orders. Wait for verification.'; end if;
  insert into manual_payments(order_code,user_id,plan_id,amount_paise) values ('TN'||upper(substr(md5(gen_random_uuid()::text),1,8)),auth.uid(),p_plan,pl.price_inr*100) returning * into o;
  return o;
end $$;

create or replace function public.submit_utr(p_order uuid, p_utr text) returns public.manual_payments language plpgsql security definer set search_path=public as $$
declare o public.manual_payments; u text := regexp_replace(coalesce(p_utr,''),'\s','','g');
begin
  if auth.uid() is null then raise exception 'Login required'; end if;
  if u !~ '^[0-9]{12}$' then raise exception 'UTR must be exactly 12 digits'; end if;
  update manual_payments set utr=u, status='pending_verification', submitted_at=now() where id=p_order and user_id=auth.uid() and status='awaiting_utr' returning * into o;
  if not found then raise exception 'Order not found or UTR already submitted'; end if;
  insert into notifications(user_id,title,body) values (auth.uid(),'Payment submitted','Order '||o.order_code||' is pending verification (up to 2.5 hours). Your plan is not active yet.');
  return o;
exception when unique_violation then raise exception 'This UTR has already been submitted';
end $$;

create or replace function public.admin_review_payment(p_id uuid, p_approve boolean, p_reason text default null) returns public.manual_payments language plpgsql security definer set search_path=public as $$
declare o public.manual_payments; pl public.plans;
begin
  if not public.is_admin() then raise exception 'Forbidden'; end if;
  select * into o from manual_payments where id=p_id for update;          -- row lock: no double activation
  if not found then raise exception 'Payment not found'; end if;
  if o.status <> 'pending_verification' then raise exception 'Payment is not pending verification'; end if;
  if o.user_id = auth.uid() then raise exception 'Admins cannot review their own payment'; end if;
  if p_approve then
    select * into pl from plans where id=o.plan_id;
    update manual_payments set status='approved', reviewed_by=auth.uid(), reviewed_at=now(), activated_at=now() where id=p_id returning * into o;
    update profiles set plan_id=o.plan_id, credits=pl.ai_credits, plan_expires_at=greatest(coalesce(plan_expires_at,now()),now())+interval '30 days' where id=o.user_id;
    insert into notifications(user_id,title,body) values (o.user_id,'Payment approved','Your '||pl.name||' plan is now active for 30 days. Order '||o.order_code||'.');
  else
    update manual_payments set status='rejected', reviewed_by=auth.uid(), reviewed_at=now(), reject_reason=left(coalesce(nullif(trim(p_reason),''),'Could not verify payment'),300) where id=p_id returning * into o;
    insert into notifications(user_id,title,body) values (o.user_id,'Payment rejected','Order '||o.order_code||': '||o.reject_reason||'. Contact support if you believe this is a mistake.');
  end if;
  insert into audit_logs(actor,action,detail) values (auth.uid(), case when p_approve then 'upi_approved' else 'upi_rejected' end, jsonb_build_object('payment',o.id,'order',o.order_code,'utr',o.utr,'user',o.user_id));
  return o;
end $$;

revoke all on function public.create_upi_order(text), public.submit_utr(uuid,text), public.admin_review_payment(uuid,boolean,text) from public, anon;
grant execute on function public.create_upi_order(text), public.submit_utr(uuid,text), public.admin_review_payment(uuid,boolean,text) to authenticated;
