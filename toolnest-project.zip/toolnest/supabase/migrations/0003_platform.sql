-- Yearly billing, usage tracking, plan expiry, admin plan control.
alter table public.plans add column price_yearly_inr int;
update public.plans set price_yearly_inr = price_inr*10;   -- 2 months free; editable in Admin
alter table public.manual_payments add column billing_cycle text not null default 'monthly' check (billing_cycle in ('monthly','yearly'));
alter table public.payments add column billing_cycle text not null default 'monthly';
alter table public.ai_usage add column tool text, add column tokens int;

create or replace function public.expire_user_plan(p_user uuid) returns void language sql security definer set search_path=public as $$
  update profiles set plan_id='free', credits=least(credits,(select ai_credits from plans where id='free')), plan_expires_at=null
  where id=p_user and plan_id<>'free' and plan_expires_at is not null and plan_expires_at<now() $$;
revoke all on function public.expire_user_plan(uuid) from public, anon, authenticated; grant execute on function public.expire_user_plan(uuid) to service_role;

drop function if exists public.create_upi_order(text);
create or replace function public.create_upi_order(p_plan text, p_cycle text default 'monthly') returns public.manual_payments language plpgsql security definer set search_path=public as $$
declare pl public.plans; o public.manual_payments; amt int;
begin
  if auth.uid() is null then raise exception 'Login required'; end if;
  if p_cycle not in ('monthly','yearly') then raise exception 'Invalid billing cycle'; end if;
  select * into pl from plans where id=p_plan and active and price_inr>0; if not found then raise exception 'Invalid plan'; end if;
  amt := case when p_cycle='yearly' then coalesce(pl.price_yearly_inr, pl.price_inr*10) else pl.price_inr end;
  select * into o from manual_payments where user_id=auth.uid() and plan_id=p_plan and billing_cycle=p_cycle and status='awaiting_utr' limit 1;
  if found then return o; end if;
  if (select count(*) from manual_payments where user_id=auth.uid() and status in ('awaiting_utr','pending_verification'))>=3 then raise exception 'Too many open orders. Wait for verification.'; end if;
  insert into manual_payments(order_code,user_id,plan_id,amount_paise,billing_cycle) values ('TN'||upper(substr(md5(gen_random_uuid()::text),1,8)),auth.uid(),p_plan,amt*100,p_cycle) returning * into o;
  return o;
end $$;
revoke all on function public.create_upi_order(text,text) from public, anon; grant execute on function public.create_upi_order(text,text) to authenticated;

-- Approval now honours billing cycle (yearly = 365 days and 12x monthly credits, granted up front).
create or replace function public.admin_review_payment(p_id uuid, p_approve boolean, p_reason text default null) returns public.manual_payments language plpgsql security definer set search_path=public as $$
declare o public.manual_payments; pl public.plans; yr boolean;
begin
  if not public.is_admin() then raise exception 'Forbidden'; end if;
  select * into o from manual_payments where id=p_id for update;
  if not found then raise exception 'Payment not found'; end if;
  if o.status <> 'pending_verification' then raise exception 'Payment is not pending verification'; end if;
  if o.user_id = auth.uid() then raise exception 'Admins cannot review their own payment'; end if;
  if p_approve then
    select * into pl from plans where id=o.plan_id; yr := o.billing_cycle='yearly';
    update manual_payments set status='approved', reviewed_by=auth.uid(), reviewed_at=now(), activated_at=now() where id=p_id returning * into o;
    update profiles set plan_id=o.plan_id, credits=pl.ai_credits*(case when yr then 12 else 1 end),
      plan_expires_at=greatest(coalesce(plan_expires_at,now()),now())+(case when yr then interval '365 days' else interval '30 days' end) where id=o.user_id;
    insert into notifications(user_id,title,body) values (o.user_id,'Payment approved','Your '||pl.name||' plan ('||o.billing_cycle||') is now active. Order '||o.order_code||'.');
  else
    update manual_payments set status='rejected', reviewed_by=auth.uid(), reviewed_at=now(), reject_reason=left(coalesce(nullif(trim(p_reason),''),'Could not verify payment'),300) where id=p_id returning * into o;
    insert into notifications(user_id,title,body) values (o.user_id,'Payment rejected','Order '||o.order_code||': '||o.reject_reason||'. Contact support if this is a mistake.');
  end if;
  insert into audit_logs(actor,action,detail) values (auth.uid(), case when p_approve then 'upi_approved' else 'upi_rejected' end, jsonb_build_object('payment',o.id,'order',o.order_code,'utr',o.utr,'user',o.user_id));
  return o;
end $$;

create or replace function public.admin_set_plan(p_user uuid, p_plan text, p_days int) returns void language plpgsql security definer set search_path=public as $$
begin
  if not public.is_admin() then raise exception 'Forbidden'; end if;
  if p_days<0 or p_days>400 then raise exception 'Invalid days'; end if;
  update profiles set plan_id=p_plan, credits=(select ai_credits from plans where id=p_plan), plan_expires_at=case when p_plan='free' then null else now()+make_interval(days=>p_days) end where id=p_user;
  insert into audit_logs(actor,action,detail) values (auth.uid(),'admin_set_plan',jsonb_build_object('user',p_user,'plan',p_plan,'days',p_days));
end $$;
revoke all on function public.admin_set_plan(uuid,text,int) from public, anon; grant execute on function public.admin_set_plan(uuid,text,int) to authenticated;
insert into public.settings values ('premium_tools','code,resume') on conflict do nothing;
