-- TOOLNEST core schema. Run via `supabase db push`.
create table public.plans (id text primary key, name text not null, price_inr int not null check (price_inr>=0), ai_credits int not null, history_limit int not null, active boolean not null default true);
insert into public.plans values ('free','Free',0,20,20,true),('mini','Mini',29,150,50,true),('pro','Pro',79,500,200,true),('max','Max',149,1500,1000,true);

create table public.profiles (id uuid primary key references auth.users on delete cascade, email text, full_name text,
  role text not null default 'user' check (role in ('user','admin')), plan_id text not null default 'free' references public.plans,
  credits int not null default 20 check (credits>=0), plan_expires_at timestamptz, created_at timestamptz not null default now());
create table public.conversations (id uuid primary key default gen_random_uuid(), user_id uuid not null references auth.users on delete cascade, title text, created_at timestamptz default now());
create table public.messages (id uuid primary key default gen_random_uuid(), conversation_id uuid not null references public.conversations on delete cascade, user_id uuid not null references auth.users on delete cascade, role text not null check (role in ('user','assistant')), content text not null, created_at timestamptz default now());
create table public.ai_usage (id bigint generated always as identity primary key, user_id uuid not null references auth.users on delete cascade, model text, credits int not null, ok boolean not null default true, created_at timestamptz default now());
create table public.tool_usage (id bigint generated always as identity primary key, user_id uuid not null references auth.users on delete cascade, tool_id text not null, created_at timestamptz default now());
create table public.tickets (id uuid primary key default gen_random_uuid(), user_id uuid references auth.users on delete set null, email text not null, subject text not null check (char_length(subject)<=200), body text not null check (char_length(body)<=5000), status text not null default 'open' check (status in ('open','closed')), created_at timestamptz default now());
create table public.payments (id uuid primary key default gen_random_uuid(), user_id uuid not null references auth.users on delete cascade, plan_id text not null references public.plans, amount_paise int not null,
  provider text not null default 'razorpay', provider_order_id text unique not null, provider_payment_id text unique, status text not null default 'created' check (status in ('created','paid','failed','refunded')), created_at timestamptz default now());
create table public.webhook_events (event_id text primary key, received_at timestamptz default now());
create table public.audit_logs (id bigint generated always as identity primary key, actor uuid, action text not null, detail jsonb, created_at timestamptz default now());
create table public.settings (key text primary key, value text not null);
insert into public.settings values ('ai_model','gpt-4o-mini'),('ai_requests_per_minute','10'),('credit_cost_per_message','1');

create or replace function public.is_admin() returns boolean language sql security definer stable set search_path=public as
$$ select coalesce((select role='admin' from public.profiles where id=auth.uid()),false) $$;

create or replace function public.handle_new_user() returns trigger language plpgsql security definer set search_path=public as
$$ begin insert into public.profiles(id,email) values (new.id,new.email); return new; end $$;
create trigger on_auth_user_created after insert on auth.users for each row execute function public.handle_new_user();

-- Atomic credit spend/refund: service role only.
create or replace function public.spend_credits(p_user uuid, p_cost int) returns int language plpgsql security definer set search_path=public as
$$ declare left_c int; begin update profiles set credits=credits-p_cost where id=p_user and credits>=p_cost returning credits into left_c; return left_c; end $$;
create or replace function public.refund_credits(p_user uuid, p_cost int) returns void language sql security definer set search_path=public as
$$ update profiles set credits=credits+p_cost where id=p_user $$;
revoke all on function public.spend_credits(uuid,int), public.refund_credits(uuid,int) from public, anon, authenticated;
grant execute on function public.spend_credits(uuid,int), public.refund_credits(uuid,int) to service_role;

-- RLS
alter table public.plans enable row level security; alter table public.profiles enable row level security; alter table public.conversations enable row level security;
alter table public.messages enable row level security; alter table public.ai_usage enable row level security; alter table public.tool_usage enable row level security;
alter table public.tickets enable row level security; alter table public.payments enable row level security; alter table public.webhook_events enable row level security;
alter table public.audit_logs enable row level security; alter table public.settings enable row level security;

create policy plans_read on public.plans for select using (active or public.is_admin());
create policy plans_admin on public.plans for all using (public.is_admin()) with check (public.is_admin());
create policy profiles_own on public.profiles for select using (id=auth.uid() or public.is_admin());
create policy profiles_update_own on public.profiles for update using (id=auth.uid()) with check (id=auth.uid());
-- Users may change ONLY full_name: role/plan/credits are locked by column grants.
revoke update on public.profiles from anon, authenticated; grant update (full_name) on public.profiles to authenticated;
create policy conv_own on public.conversations for all using (user_id=auth.uid()) with check (user_id=auth.uid());
create policy msg_own on public.messages for select using (user_id=auth.uid());
create policy usage_own on public.ai_usage for select using (user_id=auth.uid() or public.is_admin());
create policy tool_own_r on public.tool_usage for select using (user_id=auth.uid() or public.is_admin());
create policy tool_own_w on public.tool_usage for insert with check (user_id=auth.uid());
create policy ticket_own on public.tickets for select using (user_id=auth.uid() or public.is_admin());
create policy ticket_ins on public.tickets for insert with check (user_id=auth.uid());
create policy ticket_admin on public.tickets for update using (public.is_admin());
create policy pay_own on public.payments for select using (user_id=auth.uid() or public.is_admin());
create policy audit_admin on public.audit_logs for select using (public.is_admin());
create policy settings_admin on public.settings for all using (public.is_admin()) with check (public.is_admin());
-- webhook_events: no policies = service role only. payments/messages/ai_usage writes: service role only.
