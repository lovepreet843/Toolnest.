# TOOLNEST (v0.1 — partial build)
React + Vite + TS + Tailwind, Supabase (Auth, Postgres, Edge Functions), OpenAI Responses API, Razorpay (test mode), installable PWA.

## Setup
1. `npm install`; copy `.env.example` to `.env` and fill the 3 `VITE_` values (Supabase URL, anon key, Razorpay key id).
2. Create a Supabase project. `supabase link`, then `supabase db push` (applies `migrations/0001_init.sql`, incl. RLS).
3. Secrets: `supabase secrets set OPENAI_API_KEY=... RAZORPAY_KEY_ID=... RAZORPAY_KEY_SECRET=... RAZORPAY_WEBHOOK_SECRET=... ALLOWED_ORIGIN=https://your-domain`
4. `supabase functions deploy ai-chat razorpay-create-order` and `supabase functions deploy razorpay-webhook --no-verify-jwt`
5. Razorpay Dashboard (Test mode) → Webhooks → URL `https://<ref>.functions.supabase.co/razorpay-webhook`, events: payment.captured, payment.failed, refund.processed; use the same secret as step 3.
6. Make an admin: in the SQL editor run `update profiles set role='admin' where email='you@example.com';`
7. Create `public/icon-192.png` and `icon-512.png` (export from `icon.svg`) — required for Android install prompt.
8. `npm run dev`, then `npm run build` and deploy `dist/` (Cloudflare Pages: build `npm run build`, output `dist`, SPA fallback on).
9. Android: open the deployed HTTPS site in Chrome → menu → Install app. This is a PWA, not an APK.

## Not implemented yet
Admin UI, profile settings page, usage history page, saved conversations list, AI streaming, other AI tools, Razorpay Checkout popup, PDF/Image/Creator tools, legal pages, light theme, yearly billing. Never tested end-to-end.

## Manual UPI payments (migration 0002)
- Run `supabase db push` again. Plans become Free / Pro ₹79 / Premium ₹149 (Mini hidden; re-enable via `plans.active`).
- Edit `UPI_ID` in `src/lib/upi.ts` and replace `public/upi-qr.jpg` if your merchant details change.
- Flow: user picks plan → order `TN…` created → pays via QR/UPI ID → submits 12-digit UTR → *Pending Verification* → admin (`/admin/payments`) checks the bank statement and approves/rejects → plan activates only on approval.
- Guarantees live in SQL: unique UTR index, row-locked single activation, admin-only review function, admins cannot approve their own payment, no client write access to `manual_payments`.
- Notifications are in-app (`/notifications`). Email/push alerts are not implemented.
- Test: two accounts + one admin; submit a UTR as user A, confirm plan unchanged, then approve as admin; resubmit same UTR from user B (should fail); approve twice (second should fail); call `admin_review_payment` as a normal user (should fail).

## v0.3 additions (written, NOT yet built or tested)
Migration `0003_platform.sql`; functions `ai-tool`, `delete-account`, streaming `ai-chat`. Deploy: `supabase functions deploy ai-chat ai-tool razorpay-create-order delete-account` (+ `razorpay-webhook --no-verify-jwt`).
- **AI:** streaming chat (SSE), conversation rename/delete, regenerate, voice input + read-aloud (browser Web Speech API; Chrome/Android best), text-file upload (.txt/.md/.csv/.json). 8 AI tools use server-side prompt templates; `code` and `resume` are Pro+ (setting `premium_tools`).
- **Billing:** monthly/yearly (yearly = 365 days, 12× credits up front, default price = 10× monthly, editable in Admin). Expired plans fall back to Free on the next AI request (`expire_user_plan`); Dashboard shows expiry/renew.
- **Admin `/admin`:** stats, plan editor, system settings (model, rate limit, credit cost), user list + set plan, plus `/admin/payments`. Make an admin with: `update profiles set role='admin' where email='you@example.com';`
- **Razorpay Checkout:** button appears on the Pay page when `VITE_RAZORPAY_KEY_ID` is set; activation only via the verified webhook.
- **Android APK (Capacitor):** `npm install && npm run cap:add && npm run android:sync && npm run android:open`, then Android Studio → Build → Generate Signed Bundle/APK. Needs Android Studio + JDK 17; HTTPS Supabase URL. Icons: generate launcher/splash assets with `@capacitor/assets` from `public/icon-512.png`.
- **Legal pages are draft templates** with [placeholders]; get legal review.

## Still not implemented
PDF summarizer/analyzer (needs PDF text extraction), image generation, image analysis, secure binary file upload to storage, browser PDF/image/text/business tool suites from the earlier HTML prototype (only 3 tools ported), admin ticket inbox and blog, email/push notifications, scheduled expiry cron, automated tests.
