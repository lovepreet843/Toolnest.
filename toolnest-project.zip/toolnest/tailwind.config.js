export default { content:['./index.html','./src/**/*.{ts,tsx}'], theme:{extend:{colors:{nest:'#07081a'}}} }
