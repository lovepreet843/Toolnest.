export type Field = { k: string; l: string; t: 'num' | 'text' | 'area' | 'sel'; o?: string[] }
export type Tool = { id: string; cat: string; name: string; d: string; f: Field[]; run: (v: Record<string, string>) => [string, string][] }
const n = (s: string) => { const x = parseFloat(s); if (!isFinite(x)) throw new Error('Enter valid numbers.'); return x }
const f = (x: number) => x.toLocaleString('en-IN', { maximumFractionDigits: 2 })
export const tools: Tool[] = [
 { id: 'word-counter', cat: 'text', name: 'Word Counter', d: 'Words, characters and reading time.', f: [{ k: 't', l: 'Text', t: 'area' }],
   run: v => { const w = (v.t.match(/\S+/g) || []).length; return [['Words', String(w)], ['Characters', String(v.t.length)], ['Reading time', Math.ceil(w / 200) + ' min']] } },
 { id: 'gst-calculator', cat: 'business', name: 'GST Calculator', d: 'Add or remove GST.', f: [{ k: 'a', l: 'Amount (₹)', t: 'num' }, { k: 'r', l: 'Rate %', t: 'sel', o: ['5', '12', '18', '28'] }, { k: 'm', l: 'Mode', t: 'sel', o: ['Add GST', 'Remove GST'] }],
   run: v => { const a = n(v.a), r = n(v.r), b = v.m === 'Add GST' ? a : a / (1 + r / 100), g = b * r / 100; return [['Base', f(b)], ['GST', f(g)], ['Total', f(b + g)]] } },
 { id: 'discount-calculator', cat: 'business', name: 'Discount Calculator', d: 'Final price after discount.', f: [{ k: 'p', l: 'Price', t: 'num' }, { k: 'd', l: 'Discount %', t: 'num' }],
   run: v => { const p = n(v.p), d = n(v.d); return [['You save', f(p * d / 100)], ['Final price', f(p - p * d / 100)]] } },
]
