export const UPI_ID = 'k34598253@okicici'
export const MAX_HOURS = 2.5
export type MP = { id: string; order_code: string; plan_id: string; billing_cycle: 'monthly' | 'yearly'; amount_paise: number; utr: string | null; status: 'awaiting_utr' | 'pending_verification' | 'approved' | 'rejected'; submitted_at: string | null; created_at: string; reject_reason: string | null; user_id?: string; profiles?: { email: string } | null }
export const STATUS: Record<MP['status'], string> = { awaiting_utr: 'Awaiting UTR', pending_verification: 'Pending Verification', approved: 'Approved', rejected: 'Rejected' }
