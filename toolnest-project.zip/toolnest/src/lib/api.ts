import { supabase } from './supabase'
export async function callFn(name: string, body: unknown): Promise<Response> {
  const { data } = await supabase.auth.getSession()
  return fetch(`${import.meta.env.VITE_SUPABASE_URL}/functions/v1/${name}`, { method: 'POST', headers: { 'Content-Type': 'application/json', apikey: import.meta.env.VITE_SUPABASE_ANON_KEY as string, Authorization: `Bearer ${data.session?.access_token ?? ''}` }, body: JSON.stringify(body) })
}
export async function callJson<T = any>(name: string, body: unknown): Promise<T> {
  const r = await callFn(name, body); const j = await r.json().catch(() => ({}))
  if (!r.ok) throw new Error(j.error || 'Request failed'); return j as T
}
