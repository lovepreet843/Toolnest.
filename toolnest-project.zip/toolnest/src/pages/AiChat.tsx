import { useCallback, useEffect, useState } from 'react'; import { supabase } from '../lib/supabase'; import { callFn } from '../lib/api'
type M = { role: 'user' | 'assistant'; content: string }; type C = { id: string; title: string | null }
export default function AiChat() { document.title = 'AI Chat — TOOLNEST'
  const [convs, setConvs] = useState<C[]>([]), [cid, setCid] = useState<string | null>(null), [msgs, setMsgs] = useState<M[]>([]), [input, setInput] = useState(''), [busy, setBusy] = useState(false), [err, setErr] = useState(''), [left, setLeft] = useState<number | null>(null), [menu, setMenu] = useState(false), [mic, setMic] = useState(false)
  const loadConvs = useCallback(async () => { const { data } = await supabase.from('conversations').select('id,title').order('created_at', { ascending: false }).limit(50); setConvs((data as C[]) || []) }, [])
  useEffect(() => { loadConvs() }, [loadConvs])
  const newChat = () => { setCid(null); setMsgs([]); setErr(''); setMenu(false) }
  const open = async (id: string) => { setCid(id); setMenu(false); setErr(''); const { data } = await supabase.from('messages').select('role,content').eq('conversation_id', id).order('created_at'); setMsgs((data as M[]) || []) }
  const rename = async (c: C) => { const t = prompt('Rename conversation', c.title ?? ''); if (!t?.trim()) return; await supabase.from('conversations').update({ title: t.trim().slice(0, 80) }).eq('id', c.id); loadConvs() }
  const del = async (c: C) => { if (!confirm('Delete this conversation?')) return; await supabase.from('conversations').delete().eq('id', c.id); if (cid === c.id) newChat(); loadConvs() }
  const send = async (text: string, regenerate = false) => {
    setBusy(true); setErr(''); const base = regenerate ? msgs.slice(0, -2) : msgs
    setMsgs([...base, { role: 'user', content: text }, { role: 'assistant', content: '' }])
    try {
      const r = await callFn('ai-chat', { conversation_id: cid, message: text, stream: true, regenerate })
      if (!r.ok || !r.body) { const j = await r.json().catch(() => ({})); setMsgs(base); setErr(j.error || 'Request failed'); return }
      const rd = r.body.getReader(), dec = new TextDecoder(); let buf = ''
      for (;;) { const { done, value } = await rd.read(); if (done) break; buf += dec.decode(value, { stream: true }); const parts = buf.split('\n\n'); buf = parts.pop()!
        for (const p of parts) { if (!p.startsWith('data: ')) continue; const e = JSON.parse(p.slice(6))
          if (e.meta) { setCid(e.meta.conversation_id); setLeft(e.meta.credits_left) } else if (e.delta) setMsgs(m => { const c = [...m]; c[c.length - 1] = { role: 'assistant', content: c[c.length - 1].content + e.delta }; return c }) ; else if (e.error) setErr(e.error) } }
    } catch { setErr('Connection lost.') } finally { setBusy(false); loadConvs() } }
  const listen = () => { const SR = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition; if (!SR) return setErr('Voice input is not supported in this browser.')
    const r = new SR(); r.lang = 'en-IN'; r.onresult = (e: any) => setInput(i => (i + ' ' + e.results[0][0].transcript).trim()); r.onend = () => setMic(false); r.onerror = () => setMic(false); setMic(true); r.start() }
  const speak = (t: string) => { if (!('speechSynthesis' in window)) return setErr('Text-to-speech is not supported here.'); speechSynthesis.cancel(); speechSynthesis.speak(new SpeechSynthesisUtterance(t)) }
  const upload = async (f?: File) => { if (!f) return; if (f.size > 1e6) return setErr('Max file size is 1 MB (.txt, .md, .csv, .json).'); setInput(i => (i + '\n\n' + (f.name) + ':\n' + '').trim() + '\n' ); const t = await f.text(); setInput(i => (i + t).slice(0, 12000)) }
  const last = msgs[msgs.length - 1]
  return <div className="grid gap-4 md:grid-cols-[220px_1fr]">
    <aside className={(menu ? 'block' : 'hidden') + ' space-y-1 md:block'}><button className="btn mb-2 w-full" onClick={newChat}>+ New chat</button>
      {convs.map(c => <div key={c.id} className={'flex items-center gap-1 rounded-lg px-2 py-1 text-sm ' + (c.id === cid ? 'bg-white/10' : '')}><button className="flex-1 truncate text-left" onClick={() => open(c.id)}>{c.title || 'Untitled'}</button><button aria-label="Rename" onClick={() => rename(c)}>✎</button><button aria-label="Delete" onClick={() => del(c)}>🗑</button></div>)}</aside>
    <section><div className="flex items-center justify-between"><h1 className="text-2xl font-bold">AI Chat</h1><button className="text-sm text-violet-300 md:hidden" onClick={() => setMenu(!menu)}>History</button></div>
      {left !== null && <p className="text-sm text-slate-400">Credits left: {left}</p>}
      <div className="my-3 space-y-2">{msgs.map((m, i) => <div key={i} className={'card ' + (m.role === 'user' ? 'ml-8' : 'mr-8')}><p className="whitespace-pre-wrap">{m.content || '…'}</p>{m.role === 'assistant' && m.content && <div className="mt-2 flex gap-3 text-xs text-violet-300"><button onClick={() => navigator.clipboard.writeText(m.content)}>Copy</button><button onClick={() => speak(m.content)}>Listen</button></div>}</div>)}</div>
      {err && <p className="mb-2 text-red-300" role="alert">{err}</p>}
      <textarea className="inp h-24" value={input} onChange={e => setInput(e.target.value)} placeholder="Ask anything" aria-label="Message" />
      <div className="mt-2 flex flex-wrap items-center gap-2"><button className="btn" disabled={busy || !input.trim()} onClick={() => { const t = input; setInput(''); send(t) }}>{busy ? 'Streaming…' : 'Send'}</button>
        <button className="rounded-xl bg-white/10 px-3 py-2" onClick={listen} aria-label="Voice input">{mic ? '🎙 Listening…' : '🎙'}</button>
        <label className="cursor-pointer rounded-xl bg-white/10 px-3 py-2 text-sm">📎 File<input type="file" hidden accept=".txt,.md,.csv,.json,text/*" onChange={e => upload(e.target.files?.[0])} /></label>
        {last?.role === 'assistant' && msgs.length >= 2 && !busy && cid && <button className="text-sm text-violet-300" onClick={() => send(msgs[msgs.length - 2].content, true)}>Regenerate</button>}</div></section></div> }
