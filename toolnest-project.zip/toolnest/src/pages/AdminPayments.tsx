import { useCallback, useEffect, useState } from 'react'; import { supabase } from '../lib/supabase'; import { MP, STATUS } from '../lib/upi'
export default function AdminPayments() { document.title = 'Payment Verification — TOOLNEST'
  const [tab, setTab] = useState<'pending_verification' | 'all'>('pending_verification'), [rows, setRows] = useState<MP[]>([]), [err, setErr] = useState(''), [busy, setBusy] = useState('')
  const load = useCallback(async () => { let q = supabase.from('manual_payments').select('*, profiles(email)').neq('status', 'awaiting_utr'); if (tab !== 'all') q = q.eq('status', tab)
    const { data, error } = await q.order('submitted_at', { ascending: tab === 'pending_verification' }); error ? setErr(error.message) : setRows((data as unknown as MP[]) || []) }, [tab])
  useEffect(() => { load() }, [load])
  const review = async (r: MP, approve: boolean) => { let reason: string | null = null
    if (approve) { if (!confirm(`Approve ${r.order_code}?\n\nConfirm in your bank statement that UTR ${r.utr} credited ₹${r.amount_paise / 100}.`)) return }
    else { reason = prompt('Reason for rejection (shown to user):'); if (reason === null) return }
    setBusy(r.id); setErr(''); const { error } = await supabase.rpc('admin_review_payment', { p_id: r.id, p_approve: approve, p_reason: reason }); setBusy(''); error ? setErr(error.message) : load() }
  return <><h1 className="mb-1 text-2xl font-bold">Payment verification</h1><p className="mb-3 text-sm text-slate-400">Approve only after matching the UTR and amount in the actual bank transaction.</p>
    <div className="mb-3 flex gap-2">{(['pending_verification', 'all'] as const).map(t => <button key={t} onClick={() => setTab(t)} className={'rounded-lg px-3 py-1.5 text-sm ' + (tab === t ? 'bg-violet-600' : 'bg-white/10')}>{t === 'all' ? 'All' : 'Pending'}</button>)}</div>
    {err && <p className="mb-2 text-red-300" role="alert">{err}</p>}
    <div className="space-y-2">{rows.map(r => <div key={r.id} className="card space-y-1 text-sm"><div className="flex flex-wrap justify-between gap-2"><span className="font-mono font-bold">{r.order_code}</span><b>{STATUS[r.status]}</b></div>
      <p className="break-all">{r.profiles?.email} · <span className="capitalize">{r.plan_id}</span> · <b>₹{r.amount_paise / 100}</b></p><p>UTR <span className="font-mono">{r.utr}</span> · submitted {r.submitted_at && new Date(r.submitted_at).toLocaleString()}</p>
      {r.reject_reason && <p className="text-red-300">Reason: {r.reject_reason}</p>}
      {r.status === 'pending_verification' && <div className="flex gap-2 pt-1"><button className="btn flex-1" disabled={busy === r.id} onClick={() => review(r, true)}>Approve</button><button className="flex-1 rounded-xl border border-red-400/50 py-2 text-red-300" disabled={busy === r.id} onClick={() => review(r, false)}>Reject</button></div>}</div>)}
      {!rows.length && !err && <p className="text-slate-400">Nothing here.</p>}</div></> }
