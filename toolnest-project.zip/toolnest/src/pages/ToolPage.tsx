import { useState } from 'react'; import { useParams } from 'react-router-dom'; import { tools } from '../lib/tools'
export default function ToolPage() { const { id } = useParams(), t = tools.find(x => x.id === id)
  const [v, setV] = useState<Record<string, string>>({}), [out, setOut] = useState<[string, string][]>([]), [err, setErr] = useState('')
  if (!t) return <p>Tool not found.</p>; document.title = `${t.name} — TOOLNEST`
  const run = () => { try { setErr(''); setOut(t.run(Object.fromEntries(t.f.map(f => [f.k, v[f.k] ?? (f.o?.[0] ?? '')])))) } catch (e) { setOut([]); setErr((e as Error).message) } }
  return <><h1 className="text-2xl font-bold">{t.name}</h1><p className="mb-4 text-slate-400">{t.d}</p><div className="grid gap-4 md:grid-cols-2"><div className="space-y-3">
    {t.f.map(f => <label key={f.k} className="block text-sm text-slate-400">{f.l}{f.t === 'area' ? <textarea className="inp mt-1 h-32" onChange={e => setV({ ...v, [f.k]: e.target.value })} /> : f.t === 'sel' ? <select className="inp mt-1" onChange={e => setV({ ...v, [f.k]: e.target.value })}>{f.o!.map(o => <option key={o}>{o}</option>)}</select> : <input className="inp mt-1" type={f.t === 'num' ? 'number' : 'text'} step="any" onChange={e => setV({ ...v, [f.k]: e.target.value })} />}</label>)}
    <button className="btn" onClick={run}>Run</button></div>
    <div className="card" aria-live="polite">{err && <p className="text-red-300">{err}</p>}{out.map(([a, b]) => <div key={a} className="flex justify-between border-b border-white/10 py-2"><span>{a}</span><b>{b}</b></div>)}{!err && !out.length && <p className="text-slate-400">Output appears here.</p>}</div></div></> }
