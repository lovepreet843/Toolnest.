import { useEffect, useState } from 'react'; import { useParams, useSearchParams, Link } from 'react-router-dom'; import { supabase } from '../lib/supabase'; import { callJson } from '../lib/api'; import { UPI_ID, MAX_HOURS, MP, STATUS } from '../lib/upi'
export default function Pay() { document.title = 'Pay by UPI — TOOLNEST'; const { plan } = useParams(), [sp] = useSearchParams(), cycle = sp.get('cycle') === 'yearly' ? 'yearly' : 'monthly', [note, setNote] = useState('')
  const [o, setO] = useState<MP | null>(null), [utr, setUtr] = useState(''), [err, setErr] = useState(''), [busy, setBusy] = useState(false), [copied, setCopied] = useState('')
  useEffect(() => { supabase.rpc('create_upi_order', { p_plan: plan, p_cycle: cycle }).then(({ data, error }) => error ? setErr(error.message) : setO(data as MP)) }, [plan, cycle])
  const submit = async () => { setBusy(true); setErr(''); const { data, error } = await supabase.rpc('submit_utr', { p_order: o!.id, p_utr: utr }); setBusy(false); error ? setErr(error.message) : setO(data as MP) }
  const rzp = async () => { setErr(''); try { const d = await callJson('razorpay-create-order', { plan_id: o!.plan_id, cycle: o!.billing_cycle })
      await new Promise<void>((ok, bad) => { if ((window as any).Razorpay) return ok(); const sc = document.createElement('script'); sc.src = 'https://checkout.razorpay.com/v1/checkout.js'; sc.onload = () => ok(); sc.onerror = () => bad(new Error('Could not load Razorpay.')); document.body.appendChild(sc) })
      new (window as any).Razorpay({ key: d.key_id, amount: d.amount, currency: 'INR', order_id: d.order_id, name: 'TOOLNEST', theme: { color: '#7c3aed' }, handler: () => setNote('Payment received. Your plan activates when Razorpay confirms it to our server (usually within a minute). Check Dashboard.') }).open() } catch (e) { setErr((e as Error).message) } }
  const cp = (t: string, k: string) => { navigator.clipboard.writeText(t); setCopied(k); setTimeout(() => setCopied(''), 1500) }
  if (!o) return err ? <p className="text-red-300" role="alert">{err}</p> : <p>Creating order…</p>
  const amt = o.amount_paise / 100, link = `upi://pay?pa=${UPI_ID}&pn=TOOLNEST&am=${amt}&cu=INR&tn=${o.order_code}`
  return <div className="mx-auto max-w-md space-y-4"><h1 className="text-2xl font-bold">Pay by UPI</h1>
    <div className="card"><div className="flex justify-between"><span className="text-slate-400">Order ID</span><button onClick={() => cp(o.order_code, 'o')} className="font-mono font-bold">{o.order_code} {copied === 'o' ? '✓' : '⧉'}</button></div>
      <div className="flex justify-between"><span className="text-slate-400">Plan</span><b className="capitalize">{o.plan_id} ({o.billing_cycle})</b></div><div className="flex justify-between"><span className="text-slate-400">Amount</span><b>₹{amt}</b></div>
      <div className="flex justify-between"><span className="text-slate-400">Status</span><b className="text-amber-300">{STATUS[o.status]}</b></div></div>
    {o.status === 'awaiting_utr' && <>
      <div className="card text-center"><p className="mb-2 text-sm text-slate-300">Scan with any UPI app and pay exactly <b>₹{amt}</b>. Add <b>{o.order_code}</b> in the remark if possible.</p>
        <img src="/upi-qr.jpg" alt="TOOLNEST UPI QR code" className="mx-auto w-full max-w-xs rounded-xl bg-white" />
        <button onClick={() => cp(UPI_ID, 'u')} className="mt-3 font-mono">{UPI_ID} {copied === 'u' ? '✓ copied' : '⧉'}</button>
        <a href={link} className="btn mt-3 block md:hidden">Open UPI app</a></div>
      <div className="card space-y-2"><label className="block text-sm text-slate-400" htmlFor="utr">After paying, enter the 12-digit UTR / transaction reference</label>
        <input id="utr" className="inp font-mono" inputMode="numeric" maxLength={14} value={utr} onChange={e => setUtr(e.target.value.replace(/[^\d\s]/g, ''))} placeholder="123456789012" />
        <button className="btn w-full" disabled={busy || utr.replace(/\s/g, '').length !== 12} onClick={submit}>{busy ? 'Submitting…' : 'Submit for verification'}</button>
        {err && <p className="text-sm text-red-300" role="alert">{err}</p>}</div></>}
    {o.status === 'awaiting_utr' && import.meta.env.VITE_RAZORPAY_KEY_ID && <div className="card"><button className="btn w-full" onClick={rzp}>Pay with Razorpay (cards, UPI, netbanking)</button>{note && <p className="mt-2 text-sm text-emerald-300">{note}</p>}</div>}
    {o.status === 'pending_verification' && <div className="card border-amber-400/40"><p><b>Pending verification.</b> We check each payment against our bank account. This takes up to {MAX_HOURS} hours.</p><p className="mt-2 text-sm text-slate-400">Your plan is activated only after an admin confirms the payment. Submitting a UTR does not activate it. UTR: <span className="font-mono">{o.utr}</span></p></div>}
    {o.status === 'approved' && <div className="card"><p className="text-emerald-300">Approved — your plan is active.</p></div>}
    {o.status === 'rejected' && <div className="card"><p className="text-red-300">Rejected: {o.reject_reason}</p></div>}
    <Link to="/payments" className="block text-center text-sm text-violet-300">View my payments</Link></div> }
export function MyPayments() { document.title = 'My Payments — TOOLNEST'; const [rows, setRows] = useState<MP[]>([])
  useEffect(() => { supabase.from('manual_payments').select('*').order('created_at', { ascending: false }).then(({ data }) => setRows((data as MP[]) || [])) }, [])
  return <><h1 className="mb-3 text-2xl font-bold">My payments</h1><div className="space-y-2">{rows.map(r => <div key={r.id} className="card flex flex-wrap justify-between gap-2"><span className="font-mono">{r.order_code}</span><span className="capitalize">{r.plan_id} · ₹{r.amount_paise / 100}</span><b>{STATUS[r.status]}</b><span className="w-full text-xs text-slate-400">UTR {r.utr ?? '—'} · {new Date(r.created_at).toLocaleString()}{r.reject_reason ? ' · ' + r.reject_reason : ''}</span>{r.status === 'awaiting_utr' && <Link className="text-violet-300" to={`/pay/${r.plan_id}`}>Continue</Link>}</div>)}{!rows.length && <p className="text-slate-400">No payments yet.</p>}</div></> }
