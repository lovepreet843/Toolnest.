import { Link } from 'react-router-dom'
export default function Home() { document.title = 'TOOLNEST — One Platform. Hundreds of Useful Tools.'
  return <section className="py-10"><h1 className="text-4xl font-extrabold">One Platform.<br /><span className="bg-gradient-to-r from-violet-400 to-purple-300 bg-clip-text text-transparent">Hundreds of Useful Tools.</span></h1>
  <div className="mt-6 flex gap-3"><Link className="btn" to="/explore">Explore tools</Link><Link className="btn" to="/pricing">Plans</Link></div></section> }
