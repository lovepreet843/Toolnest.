import { useEffect, useState } from 'react'; import { Link } from 'react-router-dom'; import { supabase } from '../lib/supabase'
export default function Dashboard() { document.title = 'Dashboard — TOOLNEST'; const [p, setP] = useState<any>(null), [err, setErr] = useState('')
  useEffect(() => { supabase.from('profiles').select('email,full_name,plan_id,credits,plan_expires_at').single().then(({ data, error }) => error ? setErr(error.message) : setP(data)) }, [])
  if (err) return <p className="text-red-300">{err}</p>; if (!p) return <p>Loading…</p>
  const exp = p.plan_expires_at ? new Date(p.plan_expires_at) : null, expired = exp && exp < new Date(), days = exp ? Math.ceil((exp.getTime() - Date.now()) / 864e5) : 0
  return <><h1 className="mb-3 text-2xl font-bold">Welcome{p.full_name ? ', ' + p.full_name : ''}</h1>
    <div className="grid gap-3 sm:grid-cols-3"><div className="card">Plan<br /><b className="text-xl capitalize">{expired ? 'free (expired)' : p.plan_id}</b>{exp && <p className="text-xs text-slate-400">{expired ? 'Expired' : `Renews/expires in ${days} day${days === 1 ? '' : 's'}`} · {exp.toLocaleDateString()}</p>}</div><div className="card">AI credits left<br /><b className="text-xl">{p.credits}</b></div><div className="card">Email<br /><b className="break-all">{p.email}</b></div></div>
    {(p.plan_id === 'free' || expired || days <= 7) && <Link to="/pricing" className="btn mt-4 inline-block">{p.plan_id === 'free' || expired ? 'Upgrade plan' : 'Renew plan'}</Link>}
    <div className="mt-4 flex flex-wrap gap-3 text-violet-300"><Link to="/ai">AI chat</Link><Link to="/ai-tools">AI tools</Link><Link to="/usage">Usage</Link><Link to="/payments">Payments</Link><Link to="/profile">Profile</Link></div></> }
