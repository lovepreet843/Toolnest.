import { useState } from 'react'; import { useNavigate } from 'react-router-dom'; import { supabase, configured } from '../lib/supabase'
export default function Auth() { document.title = 'Login — TOOLNEST'; const nav = useNavigate()
  const [mode, setMode] = useState<'in' | 'up' | 'reset'>('in'), [email, setEmail] = useState(''), [pw, setPw] = useState(''), [msg, setMsg] = useState(''), [busy, setBusy] = useState(false)
  const go = async () => { if (!configured) return setMsg('Supabase is not configured (see .env.example).'); setBusy(true); setMsg('')
    const r = mode === 'in' ? await supabase.auth.signInWithPassword({ email, password: pw }) : mode === 'up' ? await supabase.auth.signUp({ email, password: pw, options: { emailRedirectTo: location.origin } }) : await supabase.auth.resetPasswordForEmail(email, { redirectTo: location.origin })
    setBusy(false); if (r.error) return setMsg(r.error.message); if (mode === 'in') nav('/dashboard'); else setMsg('Check your email to continue.') }
  return <div className="mx-auto max-w-sm space-y-3"><h1 className="text-2xl font-bold">{mode === 'in' ? 'Login' : mode === 'up' ? 'Create account' : 'Reset password'}</h1>
    <input className="inp" type="email" placeholder="Email" value={email} onChange={e => setEmail(e.target.value)} />
    {mode !== 'reset' && <input className="inp" type="password" placeholder="Password (min 8)" value={pw} onChange={e => setPw(e.target.value)} />}
    <button className="btn w-full" disabled={busy} onClick={go}>{busy ? 'Please wait…' : 'Continue'}</button>{msg && <p className="text-sm text-amber-300" role="alert">{msg}</p>}
    <div className="flex justify-between text-sm text-slate-400"><button onClick={() => setMode('in')}>Login</button><button onClick={() => setMode('up')}>Sign up</button><button onClick={() => setMode('reset')}>Forgot?</button></div></div> }
