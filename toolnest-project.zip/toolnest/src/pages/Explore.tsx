import { useState } from 'react'; import { Link } from 'react-router-dom'; import { tools } from '../lib/tools'
export default function Explore() { document.title = 'Explore Tools — TOOLNEST'; const [q, setQ] = useState('')
  return <><h1 className="mb-3 text-2xl font-bold">Explore tools</h1><input className="inp mb-4" placeholder="Search…" value={q} onChange={e => setQ(e.target.value)} />
  <div className="grid gap-3 sm:grid-cols-2 md:grid-cols-3">{tools.filter(t => (t.name + t.d).toLowerCase().includes(q.toLowerCase())).map(t => <Link key={t.id} to={`/tools/${t.id}`} className="card"><b>{t.name}</b><p className="text-sm text-slate-400">{t.d}</p></Link>)}</div></> }
