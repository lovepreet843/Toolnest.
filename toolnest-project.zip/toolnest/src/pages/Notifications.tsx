import { useEffect, useState } from 'react'; import { supabase } from '../lib/supabase'
type N = { id: string; title: string; body: string; read: boolean; created_at: string }
export default function Notifications() { document.title = 'Notifications — TOOLNEST'; const [n, setN] = useState<N[]>([])
  useEffect(() => { supabase.from('notifications').select('*').order('created_at', { ascending: false }).limit(50).then(async ({ data }) => { setN((data as N[]) || []); await supabase.from('notifications').update({ read: true }).eq('read', false) }) }, [])
  return <><h1 className="mb-3 text-2xl font-bold">Notifications</h1><div className="space-y-2">{n.map(x => <div key={x.id} className={'card ' + (x.read ? '' : 'border-violet-400')}><b>{x.title}</b><p className="text-sm text-slate-300">{x.body}</p><p className="text-xs text-slate-500">{new Date(x.created_at).toLocaleString()}</p></div>)}{!n.length && <p className="text-slate-400">No notifications.</p>}</div></> }
