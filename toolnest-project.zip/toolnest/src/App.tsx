import { lazy, Suspense, ReactNode } from 'react'
import { Link, Navigate, Route, Routes } from 'react-router-dom'
import { useAuth } from './auth'
import { useEffect, useState } from 'react'
import { supabase } from './lib/supabase'
const Home = lazy(() => import('./pages/Home')), Explore = lazy(() => import('./pages/Explore')), ToolPage = lazy(() => import('./pages/ToolPage')),
  Ai = lazy(() => import('./pages/AiChat')), Pricing = lazy(() => import('./pages/Pricing')), Login = lazy(() => import('./pages/Auth')), Dash = lazy(() => import('./pages/Dashboard')),
  Pay = lazy(() => import('./pages/Pay')), MyPay = lazy(() => import('./pages/Pay').then(m => ({ default: m.MyPayments }))), AdminPay = lazy(() => import('./pages/AdminPayments')), Notifs = lazy(() => import('./pages/Notifications')),
  AiTools = lazy(() => import('./pages/AiTools')), Profile = lazy(() => import('./pages/Profile')), Usage = lazy(() => import('./pages/Usage')), AdminHome = lazy(() => import('./pages/AdminHome')),
  Privacy = lazy(() => import('./pages/Info').then(m => ({ default: m.Privacy }))), Terms = lazy(() => import('./pages/Info').then(m => ({ default: m.Terms }))), Refund = lazy(() => import('./pages/Info').then(m => ({ default: m.Refund }))),
  Faq = lazy(() => import('./pages/Info').then(m => ({ default: m.Faq }))), Contact = lazy(() => import('./pages/Info').then(m => ({ default: m.Contact })))
function Private({ children }: { children: ReactNode }) { const { session, loading } = useAuth(); if (loading) return <p className="p-6">Loading…</p>; return session ? <>{children}</> : <Navigate to="/login" /> }
export default function App() {
  const { session } = useAuth(), [unread, setUnread] = useState(0), [isAdmin, setIsAdmin] = useState(false)
  useEffect(() => { if (!session) { setUnread(0); setIsAdmin(false); return }
    supabase.from('notifications').select('id', { count: 'exact', head: true }).eq('read', false).then(({ count }) => setUnread(count ?? 0))
    supabase.from('profiles').select('role').single().then(({ data }) => setIsAdmin(data?.role === 'admin')) }, [session])  // UI hint only; server enforces admin
  return <>
    <header className="sticky top-0 z-10 border-b border-white/10 bg-nest/90 backdrop-blur"><nav className="mx-auto flex max-w-5xl items-center gap-3 overflow-x-auto p-3 text-sm">
      <Link to="/" className="font-extrabold tracking-widest">TOOLNEST</Link>
      {[['/explore', 'Explore'], ['/ai-tools', 'AI Tools'], ['/ai', 'Chat'], ['/pricing', 'Pricing']].map(([p, n]) => <Link key={p} to={p} className="text-slate-300">{n}</Link>)}
      <span className="ml-auto" /><button aria-label="Toggle theme" onClick={() => { const l = document.documentElement.classList.toggle('light'); localStorage.setItem('theme', l ? 'light' : 'dark') }}>◐</button>
      {session ? <><Link to="/payments">Payments</Link>{isAdmin && <Link to="/admin">Admin</Link>}<Link to="/notifications">Alerts{unread ? ` (${unread})` : ''}</Link><Link to="/dashboard">Dashboard</Link><button onClick={() => supabase.auth.signOut()}>Logout</button></> : <Link to="/login">Login</Link>}
    </nav></header>
    <main className="mx-auto max-w-5xl p-4"><Suspense fallback={<p>Loading…</p>}><Routes>
      <Route path="/" element={<Home />} /><Route path="/explore" element={<Explore />} /><Route path="/tools/:id" element={<ToolPage />} />
      <Route path="/ai" element={<Private><Ai /></Private>} /><Route path="/pricing" element={<Pricing />} />
      <Route path="/login" element={<Login />} /><Route path="/dashboard" element={<Private><Dash /></Private>} />
      <Route path="/pay/:plan" element={<Private><Pay /></Private>} /><Route path="/payments" element={<Private><MyPay /></Private>} /><Route path="/notifications" element={<Private><Notifs /></Private>} /><Route path="/admin/payments" element={<Private><AdminPay /></Private>} />
      <Route path="/ai-tools" element={<Private><AiTools /></Private>} /><Route path="/ai-tools/:id" element={<Private><AiTools /></Private>} /><Route path="/profile" element={<Private><Profile /></Private>} /><Route path="/usage" element={<Private><Usage /></Private>} /><Route path="/admin" element={<Private><AdminHome /></Private>} />
      <Route path="/privacy" element={<Privacy />} /><Route path="/terms" element={<Terms />} /><Route path="/refund" element={<Refund />} /><Route path="/faq" element={<Faq />} /><Route path="/contact" element={<Contact />} />
      <Route path="*" element={<p>Page not found.</p>} /></Routes></Suspense></main><footer className="mx-auto flex max-w-5xl flex-wrap gap-4 p-6 text-sm text-slate-400">{[['/faq', 'FAQ'], ['/contact', 'Contact'], ['/privacy', 'Privacy'], ['/terms', 'Terms'], ['/refund', 'Refunds']].map(([p, n]) => <Link key={p} to={p}>{n}</Link>)}</footer></>
}
